#!/usr/bin/env bash
# Agentic-DART — terminal demo, part A: a REAL live run (Opus).
# Satisfies the "live terminal execution" requirement. stdout is intentionally
# quiet (header + done); the full reasoning + tool calls stream to
# out/.../live_transcript.txt and the SHA-256 audit.jsonl, shown in part B.
# OPSEC: self-evaluation synthetic case + demo persona only.
set -u
cd /home/yushin.guest/work/agentic-dart

PROMPT=$'\e[1;32myushin@siftworkstation\e[0m:\e[1;34m~/work/agentic-dart\e[0m$ '
typ(){ printf '%b' "$PROMPT"; local s="$1" i; for((i=0;i<${#s};i++)); do printf '%s' "${s:i:1}"; sleep 0.022; done; printf '\n'; }
note(){ printf '\e[1;33m# %s\e[0m\n' "$1"; sleep 0.6; }
pause(){ sleep "${1:-1.2}"; }

clear
pause 0.5
note "Hand Agentic-DART a real case — no answer key. The model reasons; the read-only"
note "tools do the looking. Reasoning + every tool call are sealed as it runs."
pause 1
typ "python3 analyze.py --case self-evaluation/case-05 --model claude-opus-4-8"
python3 analyze.py --case self-evaluation/case-05 --model claude-opus-4-8
pause 1.5
note "Header + done is all stdout shows by design — the full chain is on disk:"
typ "ls -t out/self-evaluation/case-05/ | head -1"
ls -t out/self-evaluation/case-05/ | head -1
pause 1.5
