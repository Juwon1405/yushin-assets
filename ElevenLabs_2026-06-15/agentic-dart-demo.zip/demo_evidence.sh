#!/usr/bin/env bash
# Agentic-DART — terminal demo, part B: evidence integrity & self-correction.
# Deterministic / reproducible: no API key required. A judge can re-run this.
# OPSEC: self-evaluation synthetic data + the demo persona only.
set -u
export PYTHONPATH=dart_audit/src:dart_mcp/src:dart_agent/src:dart_corr/src
cd /home/yushin.guest/work/agentic-dart

REF=examples/out/find-evil-ref-01/audit.jsonl
TRANS=out/self-evaluation/case-05/20260615T232456/live_transcript.txt

PROMPT=$'\e[1;32myushin@siftworkstation\e[0m:\e[1;34m~/work/agentic-dart\e[0m$ '
typ(){ printf '%b' "$PROMPT"; local s="$1" i; for((i=0;i<${#s};i++)); do printf '%s' "${s:i:1}"; sleep 0.022; done; printf '\n'; }
note(){ printf '\e[1;33m# %s\e[0m\n' "$1"; sleep 0.6; }
pause(){ sleep "${1:-1.2}"; }

clear
pause 0.5
note "Agentic-DART — autonomous DFIR agent: read-only tools + SHA-256 audit chain"
pause 1.2

# 1) the case catalogue
typ "python3 analyze.py --list"
python3 analyze.py --list
pause 1.6

# 2) self-correction, REPRODUCIBLE (deterministic audit chain)
note "Self-correction, captured in the audit chain (deterministic — judges can re-run):"
note "iter 3 ran analyze_usb_history on the default scope; iter 4 RE-RAN it with an"
note "added time_window. First pass was insufficient, so the agent adjusted and re-queried."
typ "jq -rc 'select(.tool_name==\"analyze_usb_history\")|{iter:.iteration,inputs:(.inputs|keys)}' $REF"
jq -rc 'select(.tool_name=="analyze_usb_history")|{iter:.iteration,inputs:(.inputs|keys)}' "$REF"
pause 2.2

# 3) self-correction, LIVE reasoning (verified Opus run, case-05)
note "The same instinct in a live Opus run (case-05): it names the contradictions in"
note "its own evidence and resolves them, instead of smoothing them over."
typ "sed -n '5,26p' out/self-evaluation/case-05/20260615T232456/live_transcript.txt"
sed -n '5,26p' "$TRANS"
pause 2.6

# 4) audit chain verify (SHA-256)
note "Every successful tool call is sealed into a SHA-256 hash chain. Verify it:"
typ "python3 -m dart_audit verify $REF"
python3 -m dart_audit verify "$REF"
pause 1.6

# 5) finding -> the exact tool executions that produced it
note "Any finding traces back to the exact tool executions behind it (F-013):"
typ "python3 -m dart_audit trace $REF F-013"
python3 -m dart_audit trace "$REF" F-013
pause 2.6

# 6) benchmark snapshot
note "Deterministic benchmark — recall, hallucinations, integrity, containment:"
typ "python3 scripts/eval/demo.py"
python3 scripts/eval/demo.py
pause 2
note "Analysis speed is security."
pause 1.6
